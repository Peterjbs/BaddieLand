# Stat Sheet Generator

## Run

npm install
npm run dev

## Build

npm run build
npm run preview
