
import React, { useEffect, useMemo, useRef, useState } from "react";
import { AlertTriangle, ClipboardCheck, Clipboard, Download, RotateCcw, Wand2, Upload, Play, X, ArrowUp, ArrowDown, ChevronDown, ChevronUp } from "lucide-react";

const LEVELS = 9;
const STEPS = LEVELS - 1;
const CAP = 5200;
const SCALE_STEP = 0.1;

const STATS = [
  { k: "HPMAX", l: "HPMAX", g: "CORE", lowest: 50, lv1Low: 70, lv1Exp: 90, lv1High: 120, lv1Limit: 180, limit: 600 },
  { k: "QUICK", l: "QUICK", g: "CORE", lowest: 15, lv1Low: 20, lv1Exp: 30, lv1High: 40, lv1Limit: 45, limit: 60 },
  { k: "BBACK", l: "BBACK", g: "CORE", lowest: 15, lv1Low: 20, lv1Exp: 30, lv1High: 40, lv1Limit: 45, limit: 60 },

  { k: "ATMEL", l: "ATMEL", g: "ATK", lowest: 0, lv1Low: 10, lv1Exp: 15, lv1High: 25, lv1Limit: 40, limit: 220 },
  { k: "ATRNG", l: "ATRNG", g: "ATK", lowest: 0, lv1Low: 10, lv1Exp: 15, lv1High: 25, lv1Limit: 40, limit: 220 },
  { k: "ATMAG", l: "ATMAG", g: "ATK", lowest: 0, lv1Low: 10, lv1Exp: 15, lv1High: 25, lv1Limit: 40, limit: 220 },
  { k: "ATSPX", l: "ATSPX", g: "ATK", lowest: 0, lv1Low: 10, lv1Exp: 15, lv1High: 25, lv1Limit: 40, limit: 240 },

  { k: "HEALR", l: "HEALR", g: "UTIL", lowest: 0, lv1Low: 0, lv1Exp: 0, lv1High: 25, lv1Limit: 50, limit: 250 },
  { k: "ALLYX", l: "ALLYX", g: "UTIL", lowest: 0, lv1Low: 0, lv1Exp: 0, lv1High: 10, lv1Limit: 20, limit: 100 },
  { k: "ATSFX", l: "ATSFX", g: "UTIL", lowest: 0, lv1Low: 0, lv1Exp: 0, lv1High: 25, lv1Limit: 50, limit: 120 },
  { k: "THRET", l: "THRET", g: "UTIL", lowest: 0, lv1Low: 0, lv1Exp: 5, lv1High: 10, lv1Limit: 20, limit: 20 },
  { k: "SHILD", l: "SHILD", g: "UTIL", lowest: 0, lv1Low: 0, lv1Exp: 0, lv1High: 35, lv1Limit: 50, limit: 200 },

  { k: "DDMEL", l: "DDMEL", g: "DEF", lowest: 0, lv1Low: 0, lv1Exp: 0, lv1High: 8, lv1Limit: 40, limit: 50 },
  { k: "DDRNG", l: "DDRNG", g: "DEF", lowest: 0, lv1Low: 0, lv1Exp: 0, lv1High: 8, lv1Limit: 40, limit: 50 },
  { k: "DDMAG", l: "DDMAG", g: "DEF", lowest: 0, lv1Low: 0, lv1Exp: 0, lv1High: 8, lv1Limit: 40, limit: 50 },
  { k: "DDSPX", l: "DDSPX", g: "DEF", lowest: 0, lv1Low: 0, lv1Exp: 0, lv1High: 8, lv1Limit: 40, limit: 50 },

  { k: "EVADE", l: "EVADE", g: "TRT", lowest: 0, lv1Low: 0, lv1Exp: 5, lv1High: 30, lv1Limit: 40, limit: 100 },
  { k: "ACCUR", l: "ACCUR", g: "TRT", lowest: 0, lv1Low: 0, lv1Exp: 15, lv1High: 25, lv1Limit: 40, limit: 100 },
  { k: "COURG", l: "COURG", g: "TRT", lowest: 0, lv1Low: 0, lv1Exp: 5, lv1High: 10, lv1Limit: 20, limit: 20 },
  { k: "INTUI", l: "INTUI", g: "TRT", lowest: 0, lv1Low: 0, lv1Exp: 5, lv1High: 10, lv1Limit: 20, limit: 20 },
  { k: "AGGRO", l: "AGGRO", g: "TRT", lowest: 0, lv1Low: 0, lv1Exp: 5, lv1High: 10, lv1Limit: 20, limit: 20 },

  { k: "ENRGY", l: "ENRGY", g: "TRT", lowest: -20, lv1Low: -3, lv1Exp: 0, lv1High: 3, lv1Limit: 10, limit: 30, signed: true },
  { k: "REGEN", l: "REGEN", g: "TRT", lowest: -25, lv1Low: -2, lv1Exp: 0, lv1High: 2, lv1Limit: 5, limit: 25, signed: true },
];

const ATK = ["ATMEL", "ATRNG", "ATMAG", "ATSPX"];
const DEF = ["DDMEL", "DDRNG", "DDMAG", "DDSPX"];
const TRACKED = ["ATMEL", "ATRNG", "ATMAG", "ATSPX", "HEALR", "ALLYX", "ATSFX"];

const STAT_NAME = {
  HPMAX: "Health",
  QUICK: "Quick",
  BBACK: "Bounce Back",
  ATMEL: "Melee Attack",
  ATRNG: "Ranged Attack",
  ATMAG: "Magic Attack",
  ATSPX: "Special Attack",
  HEALR: "Heal",
  ALLYX: "Ally",
  ATSFX: "Effects",
  DDMEL: "Melee Defence",
  DDRNG: "Ranged Defence",
  DDMAG: "Magic Defence",
  DDSPX: "Special Defence",
  EVADE: "Evasion",
  ACCUR: "Accuracy",
  INTUI: "Intuition",
  COURG: "Courage",
  AGGRO: "Aggression",
  THRET: "Threat",
  SHILD: "Shield",
  ENRGY: "Energy",
  REGEN: "Regen",
};

const byKey = Object.fromEntries(STATS.map((s) => [s.k, s]));

const hues = (() => {
  const keys = STATS.map((s) => s.k);
  const out = {};
  let h = 18;
  for (const k of keys) {
    out[k] = h % 360;
    h += 137.508;
  }
  return out;
})();

const int = (n) => (Number.isFinite(n) ? Math.round(n) : 0);
const num = (s) => {
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
};
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
const norm3 = (s) => {
  const n = num(s);
  if (n == null) return s;
  return String(Math.round(n * 1000) / 1000);
};

const emptyMults = () => {
  const m = {};
  for (const s of STATS) m[s.k] = Array.from({ length: STEPS }, () => "1");
  return m;
};

const clone = (obj) => JSON.parse(JSON.stringify(obj));

const scaleVal = (v, factor) => {
  if (v === 0 && factor > 1) return 0;
  const n = int(v * factor);
  if (v < 0) return -Math.abs(n);
  return n;
};

const statHue = (k) => hues[k] ?? 0;
const colStyle = (k, alpha = 0.12) => ({ backgroundColor: `hsla(${statHue(k)}, 70%, 65%, ${alpha})` });
const borderStyle = (k, alpha = 0.35) => ({ borderColor: `hsla(${statHue(k)}, 70%, 40%, ${alpha})` });

const sumArr = (arr) => arr.reduce((a, x) => a + (x ?? 0), 0);
const sumAbsArr = (arr) => arr.reduce((a, x) => a + Math.abs(x ?? 0), 0);

const joinAnd = (items) => {
  const xs = (items ?? []).filter((x) => x && String(x).trim().length);
  if (xs.length <= 1) return xs[0] ?? "";
  if (xs.length === 2) return `${xs[0]} and ${xs[1]}`;
  return `${xs.slice(0, -1).join(", ")} and ${xs[xs.length - 1]}`;
};

const topKey = (grid, keys, row) => {
  let best = "";
  let bestV = null;
  for (const k of keys) {
    const v = grid[k]?.[row];
    if (v == null) continue;
    if (bestV == null || v > bestV) {
      bestV = v;
      best = k;
    }
  }
  return best;
};

const expected = (prev, k, stepIdx, mults) => {
  const meta = byKey[k];
  let mv = num(mults[k]?.[stepIdx] ?? "1");
  if (mv == null) mv = 1;
  const raw = int(prev * mv);
  const next = raw < prev ? prev : raw;
  return clamp(next, meta.lowest, meta.limit);
};

const computeGrid = (manual, mults) => {
  const grid = {};
  for (const s of STATS) {
    const k = s.k;
    const vals = Array.from({ length: LEVELS }, () => null);
    for (let r = 0; r < LEVELS; r++) {
      const ms = manual[k]?.[r];
      if (ms !== undefined) {
        const nv = num(ms);
        const v = nv == null ? 0 : int(nv);
        const hi = r === 0 ? s.lv1Limit : s.limit;
        vals[r] = clamp(v, s.lowest, hi);
        continue;
      }
      if (r === 0) continue;
      const prev = vals[r - 1];
      if (prev == null) continue;
      vals[r] = expected(prev, k, r - 1, mults);
    }
    grid[k] = vals;
  }
  return grid;
};

const derived = (grid) => {
  const ATK_SUM = Array.from({ length: LEVELS }, (_, r) => sumArr(ATK.map((k) => grid[k]?.[r] ?? 0)));
  const DEF_SUM = Array.from({ length: LEVELS }, (_, r) => sumArr(DEF.map((k) => grid[k]?.[r] ?? 0)));
  const ATK_TOP = Array.from({ length: LEVELS }, (_, r) => topKey(grid, ATK, r));
  const DEF_TOP = Array.from({ length: LEVELS }, (_, r) => topKey(grid, DEF, r));
  const LV_TOTAL = Array.from({ length: LEVELS }, (_, r) => sumAbsArr(STATS.map((s) => grid[s.k]?.[r] ?? 0)));
  const TOTAL = sumAbsArr(STATS.flatMap((s) => grid[s.k] ?? []).map((v) => v ?? 0));
  return { ATK_SUM, DEF_SUM, ATK_TOP, DEF_TOP, LV_TOTAL, TOTAL };
};

const buildTrackedPanels = (grid, manual, mults) => {
  const firstNonZero = {};
  const act = {};
  const jumps = {};
  for (const k of TRACKED) {
    let first = null;
    for (let r = 0; r < LEVELS; r++) {
      const v = grid[k]?.[r] ?? 0;
      if (v > 0) {
        first = r;
        break;
      }
    }
    if (first != null) {
      firstNonZero[k] = first;
      (act[first] ||= []).push({ k, v: grid[k][first] ?? 0 });
    }
  }
  for (const k of TRACKED) {
    const col = manual[k];
    if (!col) continue;
    for (const idx of Object.keys(col)) {
      const r = Number(idx);
      if (!(r > 0 && r < LEVELS)) continue;
      if (firstNonZero[k] != null && r === firstNonZero[k]) continue;
      const prev = grid[k]?.[r - 1];
      const cur = grid[k]?.[r];
      if (prev == null || cur == null) continue;
      const exp = expected(prev, k, r - 1, mults);
      const d = cur - exp;
      if (d > 0) (jumps[r] ||= []).push({ k, d });
    }
  }
  const order = new Map(TRACKED.map((k, i) => [k, i]));
  for (const r of Object.keys(act)) act[Number(r)].sort((a, b) => order.get(a.k) - order.get(b.k));
  for (const r of Object.keys(jumps)) jumps[Number(r)].sort((a, b) => order.get(a.k) - order.get(b.k));
  const timelineLines = [];
  for (let r = 0; r < LEVELS; r++) {
    const learns = (act[r] ?? []).map((it) => `LEARN ${STAT_NAME[it.k] ?? it.k}`);
    const boosts = (jumps[r] ?? []).map((it) => (STAT_NAME[it.k] ?? it.k));
    const parts = [];
    if (learns.length) parts.push(learns.join(", "));
    if (boosts.length) parts.push(`BOOST ${joinAnd(boosts)}`);
    if (parts.length) timelineLines.push(`Level ${r + 1}: ${parts.join("; ")}`);
  }
  return { firstNonZero, timelineLines, act, jumps };
};

const Collapsible = ({ title, right, defaultOpen = true, children }) => {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-2xl border bg-white overflow-hidden">
      <div className="px-3 py-2 flex items-center justify-between gap-3 hover:bg-black/[0.02]">
        <button type="button" className="inline-flex items-center gap-2" onClick={() => setOpen((o) => !o)}>
          <span className="text-xs font-semibold text-black/60">{title}</span>
          {open ? <ChevronUp className="h-4 w-4 text-black/40" /> : <ChevronDown className="h-4 w-4 text-black/40" />}
        </button>
        {right ? <div className="flex items-center gap-2">{right}</div> : null}
      </div>
      {open && <div className="border-t p-3">{children}</div>}
    </div>
  );
};

const groupKeys = {
  CORE: ["HPMAX", "QUICK", "BBACK"],
  ATK,
  DEF,
  TRT: ["EVADE", "ACCUR", "COURG", "INTUI", "AGGRO", "ENRGY", "REGEN"],
  UTIL: ["HEALR", "ALLYX", "ATSFX", "THRET", "SHILD"],
};

const tagConflicts = {
  MAGE: ["NO_MAGIC"],
  NO_MAGIC: ["MAGE"],
  PACIFIST: ["ATTACKER", "BRUISER", "ASSASSIN", "ARTILLERY", "PURE_MAGE", "BATTLEMAGE", "DUELIST", "HIT_RUN", "SPELLBLADE"],
  NO_EVA: ["EVASIVE", "EVASION_SPEC"],
  EVASIVE: ["NO_EVA"],
  EVASION_SPEC: ["NO_EVA"],
  FRONTLOADED: ["BACKLOADED"],
  BACKLOADED: ["FRONTLOADED"],
  STEADY: ["SPIKY"],
  SPIKY: ["STEADY"],
  CLOSE_ONLY: ["SHOOTER", "ARTILLERY", "ARCANE_SNIPER", "HIT_RUN"],
  SHOOTER: ["CLOSE_ONLY"],
  WEAK_ATTACK: ["ATTACKER", "BRUISER", "ASSASSIN", "ARTILLERY", "PURE_MAGE", "BATTLEMAGE", "DUELIST"],
  ATTACKER: ["WEAK_ATTACK"],
  PURE_SUPPORT: ["ATTACKER", "BRUISER", "ASSASSIN", "ARTILLERY", "PURE_MAGE", "BATTLEMAGE", "DUELIST"],
  NO_EFFECTS: ["EFFECTER", "CONTROLLER", "TRICK_SHOOTER"],
};

const TAGS = [
  { id: "NO_EVA", name: "1 No Evasion", selectable: true, check: (ctx) => ctx.sum("EVADE") === 0, apply: (p) => p.zero("EVADE") },
  { id: "NO_COURG", name: "2 No Courage", selectable: true, check: (ctx) => ctx.sum("COURG") === 0, apply: (p) => p.zero("COURG") },
  { id: "NO_INTUI", name: "3 No Intuition", selectable: true, check: (ctx) => ctx.sum("INTUI") === 0, apply: (p) => p.zero("INTUI") },
  { id: "NO_AGGRO", name: "4 No Aggression", selectable: true, check: (ctx) => ctx.sum("AGGRO") === 0, apply: (p) => p.zero("AGGRO") },
  { id: "NO_ALLY", name: "5 No Ally", selectable: true, check: (ctx) => ctx.sum("ALLYX") === 0, apply: (p) => p.zero("ALLYX") },
  { id: "NO_EFFECTS", name: "6 No Effects", selectable: true, check: (ctx) => ctx.sum("ATSFX") === 0, apply: (p) => p.zero("ATSFX") },

  { id: "PACIFIST", name: "7 Pacifist", selectable: true, check: (ctx) => ctx.sumGroup("ATK") === 0, apply: (p) => p.zeroGroup("ATK") },
  { id: "GLASS_CANNON", name: "8 Glass Cannon Only", selectable: true, check: (ctx) => ctx.sumGroup("DEF") === 0, apply: (p) => p.zeroGroup("DEF") },
  { id: "NO_MELEE", name: "9 No Melee", selectable: true, check: (ctx) => ctx.sum("ATMEL") === 0, apply: (p) => p.zero("ATMEL") },
  { id: "NO_RANGED", name: "10 No Ranged", selectable: true, check: (ctx) => ctx.sum("ATRNG") === 0, apply: (p) => p.zero("ATRNG") },
  { id: "NO_MAGIC", name: "11 No Magic", selectable: true, check: (ctx) => ctx.sum("ATMAG") === 0, apply: (p) => p.zero("ATMAG") },
  { id: "NO_SPECIAL", name: "12 No Special", selectable: true, check: (ctx) => ctx.sum("ATSPX") === 0, apply: (p) => p.zero("ATSPX") },

  { id: "FRONTLOADED", name: "17 Frontloaded", selectable: true, check: (ctx) => ctx.frontloaded(), apply: (p) => p.setGrowth("front") },
  { id: "BACKLOADED", name: "18 Backloaded", selectable: true, check: (ctx) => ctx.backloaded(), apply: (p) => p.setGrowth("back") },
  { id: "STEADY", name: "19 Steady Growth", selectable: true, check: (ctx) => ctx.steady(), apply: (p) => p.setGrowth("steady") },
  { id: "SPIKY", name: "20 Spiky Growth", selectable: true, check: (ctx) => ctx.spiky(), apply: (p) => p.setGrowth("spike") },
  { id: "LATE_SPIKE", name: "21 Late Spike", selectable: true, check: (ctx) => ctx.lateSpike(), apply: (p) => p.setGrowth("lateSpike") },
  { id: "EARLY_SPIKE", name: "22 Early Spike", selectable: true, check: (ctx) => ctx.earlySpike(), apply: (p) => p.setGrowth("earlySpike") },

  { id: "HIGH_HEALTH", name: "High Health", selectable: true, check: (ctx) => (ctx.l9("HPMAX") >= 350) || (ctx.l1("HPMAX") >= 110), apply: (p) => p.ensureL9("HPMAX", 350) },
  { id: "LOW_HEALTH", name: "Low Health", selectable: true, check: (ctx) => ctx.l1("HPMAX") < 70, apply: (p) => p.setL1("HPMAX", 69) },

  { id: "MAGE", name: "Mage", selectable: true, check: (ctx) => ctx.sum("ATMAG") > Math.max(ctx.sum("ATMEL"), ctx.sum("ATRNG")), apply: (p) => p.makeTopAttack("ATMAG") },
  { id: "ALLY_TAG", name: "Ally", selectable: true, check: (ctx) => ctx.max("ALLYX") > 0, apply: (p) => p.ensureL1NonZero("ALLYX") },
  { id: "HEALER", name: "Healer", selectable: true, check: (ctx) => ctx.max("HEALR") > 0, apply: (p) => p.ensureL1NonZero("HEALR") },
  { id: "EFFECTER", name: "Effecter", selectable: true, check: (ctx) => ctx.sum("ATSFX") >= 200, apply: (p) => p.ensureSum("ATSFX", 200) },

  { id: "DEFENDER", name: "Defender", selectable: true, check: (ctx) => (ctx.sumGroup("DEF") + 0.5 * ctx.sum("SHILD")) * 3 > ctx.sumGroup("ATK"), apply: (p) => p.enforceDefender() },
  { id: "EVASIVE", name: "Evasive", selectable: true, check: (ctx) => (ctx.l1("EVADE") >= 25) || (ctx.max("EVADE") >= 40) || (ctx.sum("EVADE") >= 180), apply: (p) => p.ensureL1("EVADE", 30) },
  { id: "ATTACKER", name: "Attacker", selectable: true, check: (ctx) => Math.max(ctx.sum("ATMEL"), ctx.sum("ATRNG"), ctx.sum("ATMAG")) >= 650 || ctx.sumGroup("ATK") >= 950, apply: (p) => p.ensureAttacker() },
  { id: "WEAK_ATTACK", name: "Weak Attack", selectable: true, check: (ctx) => Math.max(ctx.sum("ATMEL"), ctx.sum("ATRNG"), ctx.sum("ATMAG")) < 520 && ctx.sumGroup("ATK") < 750, apply: (p) => p.weakenAttacks() },
  { id: "SHOOTER", name: "Shooter", selectable: true, check: (ctx) => ctx.topAttack() === "ATRNG", apply: (p) => p.makeTopAttack("ATRNG") },

  { id: "SPEEDY", name: "Speedy", selectable: true, check: (ctx) => ctx.max("QUICK") >= 45 || ctx.max("BBACK") >= 45, apply: (p) => p.ensureL1("QUICK", 45) },
  { id: "AGGRESSIVE", name: "Aggressive", selectable: true, check: (ctx) => ctx.sum("AGGRO") >= 100, apply: (p) => p.ensureSum("AGGRO", 100) },

  { id: "CLOSE_ONLY", name: "Close Combat Only", selectable: true, check: (ctx) => ctx.sum("ATRNG") === 0 && ctx.sum("ATMAG") === 0, apply: (p) => { p.zero("ATRNG"); p.zero("ATMAG"); } },
  { id: "POWER_MOVE", name: "Power Move", selectable: true, check: (ctx) => ctx.max("ATSPX") > 90, apply: (p) => p.ensureMax("ATSPX", 95) },
  { id: "DIVERSE_ATTACK", name: "diverse attacker", selectable: true, check: (ctx) => ctx.l1("ATMEL") > 0 && ctx.l1("ATMAG") > 0 && ctx.l1("ATSFX") > 0, apply: (p) => { p.ensureL1NonZero("ATMEL"); p.ensureL1NonZero("ATMAG"); p.ensureL1NonZero("ATSFX"); } },
  { id: "INCORPOREAL", name: "Incorporeal", selectable: true, check: (ctx) => ctx.l1("DDMEL") >= 30 && ctx.l1("DDRNG") >= 30, apply: (p) => { p.ensureL1("DDMEL", 30); p.ensureL1("DDRNG", 30); } },

  { id: "BRUISER", name: "23 Bruiser", selectable: true, check: (ctx) => ctx.sumGroup("ATK") >= 900 && ctx.l9("HPMAX") >= 220 && ctx.sumGroup("DEF") <= 0.6 * ctx.sumGroup("ATK"), apply: (p) => { p.ensureAttacker(); p.ensureL9("HPMAX", 260); } },
  { id: "TANK", name: "24 Tank", selectable: true, check: (ctx) => ctx.l9("HPMAX") >= 320 && (ctx.sumGroup("DEF") >= 260 || ctx.sum("SHILD") >= 220 || ctx.sum("THRET") >= 140), apply: (p) => { p.ensureL9("HPMAX", 360); p.ensureSum("SHILD", 220); p.ensureSum("THRET", 140); } },
  { id: "ASSASSIN", name: "25 Assassin", selectable: true, check: (ctx) => (ctx.max("QUICK") >= 40 || ctx.l1("EVADE") >= 25) && ctx.sumGroup("ATK") >= 750 && ctx.l1("HPMAX") <= 80 && ctx.sumGroup("DEF") === 0, apply: (p) => { p.ensureL1("HPMAX", 80); p.ensureL1("QUICK", 40); p.ensureAttacker(); p.zeroGroup("DEF"); p.ensureL1("EVADE", 30); } },
  { id: "SKIRMISHER", name: "26 Skirmisher", selectable: true, check: (ctx) => ctx.max("QUICK") >= 40 && (ctx.sum("ATRNG") >= 450 || ctx.sum("ATMEL") >= 450) && ctx.l9("HPMAX") >= 200, apply: (p) => { p.ensureL1("QUICK", 40); p.ensureL9("HPMAX", 240); p.ensureSum(p.pickPrimary(["ATRNG","ATMEL"]), 450); } },
  { id: "ARTILLERY", name: "27 Artillery", selectable: true, check: (ctx) => ctx.sum("ATRNG") >= 520 && ctx.sum("ATRNG") >= 1.25*Math.max(ctx.sum("ATMEL"), ctx.sum("ATMAG")), apply: (p) => { p.makeTopAttack("ATRNG"); p.ensureSum("ATRNG", 520); p.ensureSum("ACCUR", 120); } },
  { id: "BATTLEMAGE", name: "28 Battlemage", selectable: true, check: (ctx) => ctx.sum("ATMAG") >= 420 && (ctx.sum("ATMEL")+ctx.sum("ATRNG")) >= 320, apply: (p) => { p.ensureSum("ATMAG", 420); p.ensureSum("ATMEL", 180); p.ensureSum("ATRNG", 180); } },
  { id: "PURE_MAGE", name: "29 Pure Mage", selectable: true, check: (ctx) => ctx.sum("ATMAG") >= 520 && ctx.sum("ATMAG") >= 1.5*Math.max(ctx.sum("ATMEL"), ctx.sum("ATRNG"), ctx.sum("ATSPX")), apply: (p) => { p.makeTopAttack("ATMAG"); p.ensureSum("ATMAG", 520); p.zero("ATMEL"); p.zero("ATRNG"); } },
  { id: "DUELIST", name: "30 Duelist", selectable: true, check: (ctx) => ctx.sum("ATMEL") >= 520 && (ctx.l1("EVADE")>=25 || ctx.sum("EVADE")>=180) && ctx.sum("ALLYX")===0 && ctx.sum("HEALR")===0, apply: (p) => { p.makeTopAttack("ATMEL"); p.ensureSum("ATMEL", 520); p.ensureL1("EVADE", 30); p.zero("ALLYX"); p.zero("HEALR"); } },
  { id: "SUPPORT_HYB", name: "31 Support Hybrid", selectable: true, check: (ctx) => (ctx.sum("HEALR")+ctx.sum("ALLYX")+ctx.sum("ATSFX")+ctx.sum("SHILD")) >= 220 && ctx.sumGroup("ATK") >= 520, apply: (p) => { p.ensureSum("HEALR", 120); p.ensureSum("ATSFX", 120); p.ensureAttacker(); } },
  { id: "PURE_SUPPORT", name: "32 Pure Support", selectable: true, check: (ctx) => (ctx.sum("HEALR")+ctx.sum("ALLYX")+ctx.sum("ATSFX")+ctx.sum("SHILD")) >= 320 && ctx.sumGroup("ATK") <= 480, apply: (p) => { p.ensureSum("HEALR", 220); p.ensureSum("ALLYX", 80); p.ensureSum("SHILD", 120); p.weakenAttacks(480); } },
  { id: "CONTROLLER", name: "33 Controller", selectable: true, check: (ctx) => ctx.sum("ATSFX") >= 220 && ctx.sum("INTUI") >= 80 && (ctx.max("BBACK") >= 30 || ctx.max("ACCUR") >= 25), apply: (p) => { p.ensureSum("ATSFX", 220); p.ensureSum("INTUI", 80); p.ensureL1("BBACK", 30); } },
  { id: "ENCHANTER", name: "34 Enchanter", selectable: true, check: (ctx) => ctx.sum("ALLYX") >= 120 && (ctx.sum("SHILD")>=120 || ctx.sum("ATSFX")>=160) && ctx.sum("HEALR") <= 200, apply: (p) => { p.ensureSum("ALLYX", 120); p.ensureSum("SHILD", 120); p.capSum("HEALR", 200); } },
  { id: "SUSTAIN", name: "35 Sustain", selectable: true, check: (ctx) => ctx.sum("HEALR") >= 240 && (ctx.sumGroup("DEF")>=200 || ctx.sum("SHILD")>=180 || ctx.max("REGEN")>=2), apply: (p) => { p.ensureSum("HEALR", 240); p.ensureSum("SHILD", 180); p.ensureMax("REGEN", 2); } },

  { id: "V_HIGH_HP", name: "36 Very High Health", selectable: true, check: (ctx) => ctx.l9("HPMAX") >= 450, apply: (p) => p.ensureL9("HPMAX", 450) },
  { id: "BURST", name: "37 Burst Damage", selectable: true, check: (ctx) => ctx.maxAttackAny() >= 120, apply: (p) => p.ensureMax(p.topAttack(), 120) },
  { id: "EVA_SPEC", name: "39 Evasion Specialist", selectable: true, check: (ctx) => ctx.sum("EVADE") >= 300 || ctx.max("EVADE") >= 60, apply: (p) => { p.ensureSum("EVADE", 300); } },
  { id: "SPEED_DEMON", name: "40 Speed Demon", selectable: true, check: (ctx) => ctx.max("QUICK") >= 55 || ctx.max("BBACK") >= 55, apply: (p) => { p.ensureL1("QUICK", 55); p.ensureL1("BBACK", 55); } },
  { id: "BERSERKER", name: "41 Berserker", selectable: true, check: (ctx) => ctx.sum("AGGRO") >= 140 && ctx.sumGroup("ATK") >= 850 && ctx.sumGroup("DEF") === 0, apply: (p) => { p.ensureSum("AGGRO", 140); p.ensureAttacker(); p.zeroGroup("DEF"); } },
  { id: "LEADER", name: "42 Leader", selectable: true, check: (ctx) => ctx.sum("ALLYX") >= 160 || (ctx.l1("ALLYX")>0 && ctx.l9("ALLYX")>=ctx.l1("ALLYX")), apply: (p) => p.ensureSum("ALLYX", 160) },
  { id: "MEDIC", name: "43 Medic", selectable: true, check: (ctx) => ctx.sum("HEALR") >= 280 && ctx.l1("HEALR") > 0, apply: (p) => { p.ensureSum("HEALR", 280); p.ensureL1NonZero("HEALR"); } },
  { id: "LATE_HEAL", name: "44 Late Healer", selectable: true, check: (ctx) => ctx.firstNonZero("HEALR") >= 3, apply: (p) => p.unlockLate("HEALR", 3, 25) },
  { id: "STARTER_KIT", name: "45 Starter Kit", selectable: true, check: (ctx) => ctx.countL1Active() >= 3, apply: (p) => { p.ensureL1NonZero("ATMEL"); p.ensureL1NonZero("ATSFX"); p.ensureL1NonZero("EVADE"); } },

  { id: "UNLOCK_MAGIC_LATE", name: "52 Unlocks Magic Late", selectable: true, check: (ctx) => ctx.firstNonZero("ATMAG") >= 3, apply: (p) => p.unlockLate("ATMAG", 3, 15) },
  { id: "UNLOCK_FX_LATE", name: "53 Unlocks FX Late", selectable: true, check: (ctx) => ctx.firstNonZero("ATSFX") >= 3, apply: (p) => p.unlockLate("ATSFX", 3, 25) },
  { id: "UNLOCK_RNG_LATE", name: "54 Unlocks Ranged Late", selectable: true, check: (ctx) => ctx.firstNonZero("ATRNG") >= 3, apply: (p) => p.unlockLate("ATRNG", 3, 15) },
  { id: "OPENS_SPECIAL", name: "55 Opens with Special", selectable: true, check: (ctx) => ctx.l1("ATSPX") > 0, apply: (p) => p.ensureL1NonZero("ATSPX") },
  { id: "NO_EARLY_UTIL", name: "56 No Early Utility", selectable: true, check: (ctx) => ctx.allZeroL13(["HEALR","ALLYX","ATSFX","SHILD"]), apply: (p) => p.zeroL13(["HEALR","ALLYX","ATSFX","SHILD"]) },
  { id: "UTIL_FIRST", name: "57 Utility First", selectable: true, check: (ctx) => ctx.anyNonZeroL1(["HEALR","ALLYX","ATSFX","SHILD"]) && ctx.sumGroupL1("ATK")===0, apply: (p) => { p.zeroGroupL1("ATK"); p.ensureL1NonZero("ATSFX"); } },

  { id: "HIT_RUN", name: "58 Hit-and-Run", selectable: true, check: (ctx) => ctx.max("QUICK") >= 40 && ctx.sum("ATRNG") >= 520 && ctx.sumGroup("DEF") <= 0.6*ctx.sumGroup("ATK"), apply: (p) => { p.ensureL1("QUICK", 40); p.makeTopAttack("ATRNG"); p.ensureSum("ATRNG", 520); } },
  { id: "JUGGER", name: "59 Juggernaut", selectable: true, check: (ctx) => ctx.l9("HPMAX") >= 400 && (ctx.sumGroup("DEF")>=240 || ctx.sum("SHILD")>=220) && ctx.max("QUICK") <= 30, apply: (p) => { p.ensureL9("HPMAX", 420); p.ensureSum("SHILD", 220); p.ensureL1("QUICK", 30); } },
  { id: "VAMP", name: "60 Vampiric Style", selectable: true, check: (ctx) => ctx.sum("HEALR") >= 160 && ctx.sumGroup("ATK") >= 850 && ctx.sumGroup("DEF") === 0, apply: (p) => { p.ensureSum("HEALR", 160); p.ensureAttacker(); p.zeroGroup("DEF"); } },
  { id: "GUARD_ANGEL", name: "61 Guardian Angel", selectable: true, check: (ctx) => ctx.sum("ALLYX") >= 140 && ctx.sum("HEALR") >= 220 && (ctx.sum("SHILD") >= 140 || ctx.sumGroup("DEF")>=200), apply: (p) => { p.ensureSum("ALLYX", 140); p.ensureSum("HEALR", 220); p.ensureSum("SHILD", 140); } },
  { id: "TRICK_SHOOTER", name: "62 Trick Shooter", selectable: true, check: (ctx) => ctx.topAttack()==="ATRNG" && ctx.sum("ATSFX")>=160 && ctx.sum("INTUI")>=60 && ctx.max("ACCUR")>=25, apply: (p) => { p.makeTopAttack("ATRNG"); p.ensureSum("ATSFX", 160); p.ensureSum("INTUI", 60); p.ensureMax("ACCUR", 25); } },
  { id: "ARCANE_SNIPER", name: "63 Arcane Sniper", selectable: true, check: (ctx) => ctx.sum("ATRNG")>=420 && ctx.sum("ATMAG")>=420 && ctx.sum("ATMEL")<=260, apply: (p) => { p.ensureSum("ATRNG", 420); p.ensureSum("ATMAG", 420); p.capSum("ATMEL", 260); } },
  { id: "SPELLBLADE", name: "64 Spellblade", selectable: true, check: (ctx) => ctx.sum("ATMEL")>=360 && ctx.sum("ATMAG")>=360 && (ctx.sumGroup("DEF")>=160 || ctx.sum("SHILD")>=140), apply: (p) => { p.ensureSum("ATMEL", 360); p.ensureSum("ATMAG", 360); p.ensureSum("SHILD", 140); } },
  { id: "CAUTIOUS", name: "65 Cautious Genius", selectable: true, check: (ctx) => ctx.sum("INTUI")>=220 && ctx.sum("AGGRO")<=80, apply: (p) => { p.ensureSum("INTUI", 220); p.capSum("AGGRO", 80); } },
  { id: "RECKLESS", name: "66 Reckless Genius", selectable: true, check: (ctx) => ctx.sum("INTUI")>=220 && ctx.sum("AGGRO")>=140, apply: (p) => { p.ensureSum("INTUI", 220); p.ensureSum("AGGRO", 140); } },
  { id: "TEAM_SOLO", name: "67 Team Soloist", selectable: true, check: (ctx) => ctx.sum("ALLYX")==0 && ctx.sum("HEALR")==0 && ctx.sum("ATSFX")==0 && ctx.sum("SHILD")==0 && ctx.sumGroup("ATK")>=850, apply: (p) => { p.zero("ALLYX"); p.zero("HEALR"); p.zero("ATSFX"); p.zero("SHILD"); p.ensureAttacker(); } },
];

const mkCtx = (grid, mults) => {
  const d = derived(grid);
  const l1 = (k) => grid[k]?.[0] ?? 0;
  const l9 = (k) => grid[k]?.[8] ?? 0;
  const sum = (k) => sumArr(grid[k] ?? Array(LEVELS).fill(0));
  const max = (k) => Math.max(...(grid[k] ?? Array(LEVELS).fill(0)).map((x) => x ?? 0));
  const sumGroup = (g) => sumArr(groupKeys[g].map((k) => sum(k)));
  const sumGroupL1 = (g) => sumArr(groupKeys[g].map((k) => l1(k)));
  const topAttack = () => {
    const sums = ATK.map((k) => [k, sum(k)]);
    sums.sort((a, b) => b[1] - a[1]);
    return sums[0]?.[0] ?? "";
  };
  const maxAttackAny = () => Math.max(...ATK.map((k) => max(k)));
  const firstNonZero = (k) => {
    const col = grid[k] ?? [];
    for (let i = 0; i < LEVELS; i++) if ((col[i] ?? 0) > 0) return i;
    return 99;
  };
  const anyNonZeroL1 = (keys) => keys.some((k) => l1(k) > 0);
  const allZeroL13 = (keys) => keys.every((k) => (grid[k]?.[0] ?? 0) === 0 && (grid[k]?.[1] ?? 0) === 0 && (grid[k]?.[2] ?? 0) === 0);
  const countL1Active = () => {
    const keys = ["ATMEL","ATRNG","ATMAG","ATSPX","HEALR","ALLYX","ATSFX","SHILD","THRET","EVADE","ACCUR","INTUI","COURG","AGGRO"];
    return keys.reduce((a,k)=>a + (l1(k)>0 ? 1:0),0);
  };

  const multAvg = (kList) => {
    const vals = [];
    for (const k of kList) for (let i=0;i<STEPS;i++) vals.push(num(mults[k]?.[i] ?? "1") ?? 1);
    return vals.length ? vals.reduce((a,x)=>a+x,0)/vals.length : 1;
  };
  const keyGrowth = () => multAvg(["HPMAX", ...ATK]);
  const frontloaded = () => {
    const key = ["HPMAX", ...ATK];
    const early = multAvg(key.map((k)=>k).flatMap((k)=>[k]));
    const e = (()=> {
      let s=0; let c=0;
      for(const k of key) for(let i=0;i<3;i++){ s += (num(mults[k][i]) ?? 1); c++; }
      return c? s/c:1;
    })();
    const l = (()=> {
      let s=0; let c=0;
      for(const k of key) for(let i=5;i<8;i++){ s += (num(mults[k][i]) ?? 1); c++; }
      return c? s/c:1;
    })();
    return e >= 1.25 * l;
  };
  const backloaded = () => {
    const key = ["HPMAX", ...ATK];
    const e = (()=> {
      let s=0; let c=0;
      for(const k of key) for(let i=0;i<3;i++){ s += (num(mults[k][i]) ?? 1); c++; }
      return c? s/c:1;
    })();
    const l = (()=> {
      let s=0; let c=0;
      for(const k of key) for(let i=5;i<8;i++){ s += (num(mults[k][i]) ?? 1); c++; }
      return c? s/c:1;
    })();
    return l >= 1.25 * e;
  };
  const steady = () => {
    const key = ["HPMAX", ...ATK];
    let mx = -Infinity, mn = Infinity;
    for (const k of key) for (let i = 0; i < STEPS; i++) {
      const v = num(mults[k][i]) ?? 1;
      mx = Math.max(mx, v);
      mn = Math.min(mn, v);
    }
    return (mx - mn) <= 0.05;
  };
  const spiky = () => {
    const key = ["HPMAX", ...ATK];
    const vals = [];
    for (const k of key) for (let i = 0; i < STEPS; i++) vals.push(num(mults[k][i]) ?? 1);
    const avg = vals.reduce((a, x) => a + x, 0) / (vals.length || 1);
    return vals.some((v) => v >= avg + 0.2);
  };
  const lateSpike = () => {
    const key = ["HPMAX", ...ATK];
    let best = -Infinity;
    let bestIdx = 0;
    for (let i = 0; i < STEPS; i++) {
      let s = 0; let c = 0;
      for (const k of key) { s += (num(mults[k][i]) ?? 1); c++; }
      const v = c ? s / c : 1;
      if (v > best) { best = v; bestIdx = i; }
    }
    return bestIdx >= 5;
  };
  const earlySpike = () => {
    const key = ["HPMAX", ...ATK];
    let best = -Infinity;
    let bestIdx = 0;
    for (let i = 0; i < STEPS; i++) {
      let s = 0; let c = 0;
      for (const k of key) { s += (num(mults[k][i]) ?? 1); c++; }
      const v = c ? s / c : 1;
      if (v > best) { best = v; bestIdx = i; }
    }
    return bestIdx <= 2;
  };

  return { d, l1, l9, sum, max, sumGroup, sumGroupL1, topAttack, maxAttackAny, firstNonZero, anyNonZeroL1, allZeroL13, countL1Active, keyGrowth, frontloaded, backloaded, steady, spiky, lateSpike, earlySpike };
};

const mkPlanner = (state) => {
  const plan = {
    manual: clone(state.manual),
    mults: clone(state.mults),
    locks: clone(state.locks),
    setL1(k, v) {
      if (plan.locks[k]) return;
      const meta = byKey[k];
      plan.manual[k] ||= {};
      plan.manual[k][0] = String(clamp(int(v), meta.lowest, meta.lv1Limit));
    },
    ensureL1(k, v) {
      if (plan.locks[k]) return;
      const cur = num(plan.manual[k]?.[0]) ?? null;
      if (cur == null || cur < v) plan.setL1(k, v);
      if ((num(plan.manual[k]?.[0]) ?? 0) !== 0) plan.bumpToChunk(k);
    },
    ensureL1NonZero(k) {
      if (plan.locks[k]) return;
      const meta = byKey[k];
      const cur = num(plan.manual[k]?.[0]) ?? 0;
      if (cur <= 0) plan.setL1(k, meta.lv1High || meta.lv1Exp || 1);
      plan.bumpToChunk(k);
    },
    bumpToChunk(k) {
      const meta = byKey[k];
      const cur = int(num(plan.manual[k]?.[0]) ?? 0);
      if (cur === 0) return;
      const minChunk = meta.k === "EVADE" ? 25 : (meta.lv1Exp || 12);
      if (cur < minChunk) plan.setL1(k, minChunk);
    },
    zero(k) {
      const meta = byKey[k];
      plan.manual[k] = { 0: String(clamp(0, meta.lowest, meta.lv1Limit)) };
      plan.mults[k] = Array.from({ length: STEPS }, () => "1");
    },
    zeroGroup(g) {
      for (const k of groupKeys[g]) plan.zero(k);
    },
    zeroGroupL1(g) {
      for (const k of groupKeys[g]) plan.setL1(k, 0);
    },
    ensureSum(k, target) {
      if (plan.locks[k]) return;
      const grid = computeGrid(plan.manual, plan.mults);
      const cur = sumArr(grid[k].map((x) => x ?? 0));
      if (cur >= target) return;
      if (cur <= 0) {
        plan.ensureL1NonZero(k);
        return;
      }
      const l1 = grid[k][0] ?? 0;
      const ratio = target / cur;
      const meta = byKey[k];
      let next = int(l1 * ratio);
      next = clamp(next, meta.lowest, meta.lv1Limit);
      plan.setL1(k, next);
    },
    capSum(k, cap) {
      if (plan.locks[k]) return;
      const grid = computeGrid(plan.manual, plan.mults);
      const cur = sumArr(grid[k].map((x) => x ?? 0));
      if (cur <= cap) return;
      const l1 = grid[k][0] ?? 0;
      const ratio = cap / (cur || 1);
      const meta = byKey[k];
      let next = int(l1 * ratio);
      next = clamp(next, meta.lowest, meta.lv1Limit);
      plan.setL1(k, next);
    },
    ensureMax(k, target) {
      if (plan.locks[k]) return;
      const grid = computeGrid(plan.manual, plan.mults);
      const curMax = Math.max(...grid[k].map((x) => x ?? 0));
      if (curMax >= target) return;
      const meta = byKey[k];
      if ((grid[k][8] ?? 0) < target) plan.ensureL9(k, target);
      else {
        const l1 = grid[k][0] ?? 0;
        plan.setL1(k, clamp(l1 + 1, meta.lowest, meta.lv1Limit));
      }
    },
    ensureL9(k, target) {
      if (plan.locks[k]) return;
      const grid = computeGrid(plan.manual, plan.mults);
      const cur = grid[k][8] ?? 0;
      if (cur >= target) return;
      const meta = byKey[k];
      const l1 = grid[k][0] ?? 0;
      const ratio = cur > 0 ? target / cur : 10;
      let next = int(l1 * ratio);
      next = clamp(next, meta.lowest, meta.lv1Limit);
      plan.setL1(k, next);
      const g2 = computeGrid(plan.manual, plan.mults);
      if ((g2[k][8] ?? 0) < target) {
        plan.manual[k] ||= {};
        plan.manual[k][8] = String(clamp(target, meta.lowest, meta.limit));
      }
    },
    pickPrimary(cands) {
      const grid = computeGrid(plan.manual, plan.mults);
      let best = cands[0];
      let bestSum = -1;
      for (const k of cands) {
        const s = sumArr(grid[k].map((x) => x ?? 0));
        if (s > bestSum) { bestSum = s; best = k; }
      }
      return best;
    },
    makeTopAttack(k) {
      if (plan.locks[k]) return;
      for (const other of ATK) if (other !== k && !plan.locks[other]) plan.capSum(other, 520);
      plan.ensureSum(k, 650);
      plan.ensureL1NonZero(k);
    },
    topAttack() {
      const grid = computeGrid(plan.manual, plan.mults);
      const sums = ATK.map((k) => [k, sumArr(grid[k].map((x) => x ?? 0))]);
      sums.sort((a, b) => b[1] - a[1]);
      return sums[0]?.[0] ?? "";
    },
    ensureAttacker() {
      const k = plan.topAttack() || "ATMEL";
      plan.ensureSum(k, 650);
      plan.ensureL1NonZero(k);
      plan.ensureL9(k, 140);
    },
    weakenAttacks(maxTotal = 750) {
      const grid = computeGrid(plan.manual, plan.mults);
      const atkSum = sumArr(ATK.flatMap((k) => grid[k]).map((x) => Math.abs(x ?? 0)));
      if (atkSum <= maxTotal) return;
      const factor = maxTotal / (atkSum || 1);
      for (const k of ATK) {
        if (plan.locks[k]) continue;
        const l1 = grid[k][0] ?? 0;
        plan.setL1(k, int(l1 * factor));
      }
    },
    enforceDefender() {
      const grid = computeGrid(plan.manual, plan.mults);
      const atkSum = sumArr(ATK.flatMap((k) => grid[k]).map((x) => Math.abs(x ?? 0)));
      const defSum = sumArr(DEF.flatMap((k) => grid[k]).map((x) => Math.abs(x ?? 0)));
      const sh = sumArr(grid["SHILD"].map((x) => Math.abs(x ?? 0)));
      if ((defSum + 0.5 * sh) * 3 > atkSum) return;
      if (!plan.locks["SHILD"]) plan.ensureSum("SHILD", 200);
      for (const k of DEF) if (!plan.locks[k]) plan.ensureL1NonZero(k);
      plan.weakenAttacks(Math.max(480, int((defSum + 0.5 * sh) * 2.5)));
    },
    unlockLate(k, idx, l1Val) {
      if (plan.locks[k]) return;
      const meta = byKey[k];
      plan.manual[k] = { 0: "0", [idx]: String(clamp(l1Val, meta.lowest, meta.limit)) };
    },
    zeroL13(keys) {
      for (const k of keys) {
        if (plan.locks[k]) continue;
        plan.manual[k] ||= {};
        plan.manual[k][0] = "0";
        plan.manual[k][1] = "0";
        plan.manual[k][2] = "0";
      }
    },
    setGrowth(mode) {
      const patterns = {
        steady: Array.from({ length: STEPS }, () => "1.25"),
        front: ["1.45","1.35","1.25","1.15","1.10","1.07","1.05","1.05"],
        back: ["1.05","1.05","1.07","1.10","1.15","1.25","1.35","1.45"],
        spike: ["1.15","1.15","1.15","1.60","1.15","1.15","1.15","1.15"],
        lateSpike: ["1.10","1.10","1.10","1.10","1.10","1.10","1.10","1.70"],
        earlySpike: ["1.70","1.10","1.10","1.10","1.10","1.10","1.10","1.10"],
      };
      const pat = patterns[mode] || patterns.steady;
      for (const k of ["HPMAX", ...ATK, ...DEF, "EVADE", "ACCUR", "ATSFX", "ALLYX", "HEALR", "SHILD"]) {
        if (!plan.mults[k]) continue;
        plan.mults[k] = [...pat];
      }
    },
  };
  return plan;
};

const validatePlan = (manual, mults) => {
  const grid = computeGrid(manual, mults);
  const d = derived(grid);
  if (d.TOTAL > CAP) return { ok: false, reason: `Cumulative total can’t exceed ${CAP}.` };
  for (const s of STATS) {
    const col = grid[s.k];
    for (let r = 1; r < LEVELS; r++) {
      const a = col?.[r - 1];
      const b = col?.[r];
      if (a == null || b == null) continue;
      if (b < a) return { ok: false, reason: `${s.k} can’t go down (Lv${r}→Lv${r + 1}).` };
    }
    const v0 = col?.[0];
    if (v0 != null && v0 > s.lv1Limit) return { ok: false, reason: `${s.k} Lv1 exceeds Lv1 limit.` };
  }
  return { ok: true };
};

const convertOldPayload = (payload) => {
  const map = {
    HP: "HPMAX",
    SPD1: "QUICK",
    BBR: "BBACK",
    MLA: "ATMEL",
    RAA: "ATRNG",
    MAA: "ATMAG",
    SPA: "ATSPX",
    HEAL: "HEALR",
    MLD: "DDMEL",
    RAD: "DDRNG",
    MAD: "DDMAG",
    SPD2: "DDSPX",
    EVA: "EVADE",
    CRG: "COURG",
    INT: "INTUI",
    AGG: "AGGRO",
    ALY: "ALLYX",
    FX: "ATSFX",
  };
  const manual = {};
  const mults = emptyMults();
  if (payload?.multipliers?.hp?.length === 8) {
    const hp = payload.multipliers.hp;
    const atk = payload.multipliers.atk;
    const def = payload.multipliers.def;
    const trt = payload.multipliers.trt;
    for (const s of STATS) {
      if (s.k === "HPMAX") mults[s.k] = [...hp];
      else if (ATK.includes(s.k)) mults[s.k] = [...atk];
      else if (DEF.includes(s.k)) mults[s.k] = [...def];
      else if (["EVADE","COURG","INTUI","AGGRO","ALLYX","ATSFX"].includes(s.k)) mults[s.k] = [...trt];
    }
  }
  for (const oldK of Object.keys(payload?.manual || {})) {
    const nk = map[oldK];
    if (!nk) continue;
    manual[nk] = {};
    for (const r of Object.keys(payload.manual[oldK])) manual[nk][Number(r)] = payload.manual[oldK][r];
  }
  return { manual, mults };
};

function StatBoundsTable() {
  return (
    <div className="overflow-auto rounded-xl border">
      <table className="min-w-max w-full text-xs">
        <thead className="bg-white sticky top-0">
          <tr>
            <th className="text-left px-2 py-2 border-b">Code</th>
            <th className="text-right px-2 py-2 border-b">Lowest</th>
            <th className="text-right px-2 py-2 border-b">Lv1 Low</th>
            <th className="text-right px-2 py-2 border-b">Lv1 Exp</th>
            <th className="text-right px-2 py-2 border-b">Lv1 High</th>
            <th className="text-right px-2 py-2 border-b">Lv1 Limit</th>
            <th className="text-right px-2 py-2 border-b">Lv9 Limit</th>
          </tr>
        </thead>
        <tbody>
          {STATS.map((s) => (
            <tr key={s.k} className="hover:bg-black/5">
              <td className="px-2 py-1 border-b font-mono">
                <span className="inline-flex items-center gap-2">
                  <span className="inline-block h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: `hsl(${statHue(s.k)},70%,55%)` }} />
                  {s.k}
                </span>
              </td>
              <td className="px-2 py-1 border-b text-right tabular-nums">{s.lowest}</td>
              <td className="px-2 py-1 border-b text-right tabular-nums">{s.lv1Low}</td>
              <td className="px-2 py-1 border-b text-right tabular-nums">{s.lv1Exp}</td>
              <td className="px-2 py-1 border-b text-right tabular-nums">{s.lv1High}</td>
              <td className="px-2 py-1 border-b text-right tabular-nums">{s.lv1Limit}</td>
              <td className="px-2 py-1 border-b text-right tabular-nums">{s.limit}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function App() {
  const [manual, setManual] = useState({});
  const [mults, setMults] = useState(emptyMults());
  const [locks, setLocks] = useState({});
  const [selectedTags, setSelectedTags] = useState([]);
  const [ignoredTags, setIgnoredTags] = useState([]);
  const [err, setErr] = useState(null);
  const [copied, setCopied] = useState(false);
  const fileRef = useRef(null);
  const topBarRef = useRef(null);

  const grid = useMemo(() => computeGrid(manual, mults), [manual, mults]);
  const der = useMemo(() => derived(grid), [grid]);
  const tracked = useMemo(() => buildTrackedPanels(grid, manual, mults), [grid, manual, mults]);

  const ctx = useMemo(() => mkCtx(grid, mults), [grid, mults]);

  const activeTags = useMemo(() => {
    const act = [];
    for (const t of TAGS) {
      try {
        if (t.check(ctx)) act.push(t.id);
      } catch {
        continue;
      }
    }
    return act;
  }, [ctx]);

  useEffect(() => {
    const el = topBarRef.current;
    if (!el) return;
    const set = () => {
      const h = Math.ceil(el.getBoundingClientRect().height);
      document.documentElement.style.setProperty("--topbar-h", `${h}px`);
    };
    set();
    window.addEventListener("resize", set);
    return () => window.removeEventListener("resize", set);
  }, [selectedTags, ignoredTags, activeTags, der.TOTAL, err, tracked.timelineLines]);

  const fail = (m) => {
    setErr(m);
    window.setTimeout(() => setErr(null), 2200);
  };

  const setManualSafe = (next) => {
    const v = validatePlan(next, mults);
    if (!v.ok) return fail(v.reason);
    setManual(next);
  };

  const setMultSafe = (next) => {
    const v = validatePlan(manual, next);
    if (!v.ok) return fail(v.reason);
    setMults(next);
  };

  const setLocksSafe = (next) => setLocks(next);

  const setCell = (k, r, raw) => {
    if (locks[k]) return;
    const meta = byKey[k];
    const next = clone(manual);
    next[k] ||= {};
    if (raw.trim() === "") {
      delete next[k][r];
      if (Object.keys(next[k]).length === 0) delete next[k];
      return setManualSafe(next);
    }
    const nv = num(raw);
    const hi = r === 0 ? meta.lv1Limit : meta.limit;
    next[k][r] = String(clamp(int(nv == null ? 0 : nv), meta.lowest, hi));
    setManualSafe(next);
  };

  const clearCell = (k, r) => {
    if (manual[k]?.[r] === undefined) return;
    const next = clone(manual);
    delete next[k][r];
    if (Object.keys(next[k]).length === 0) delete next[k];
    setManualSafe(next);
  };

  const setMultCell = (k, step, raw) => {
    const next = clone(mults);
    const v = norm3(raw.trim() === "" ? "1" : raw);
    for (let i = step; i < STEPS; i++) next[k][i] = v;
    setMultSafe(next);
  };

  const scaleRow = (r, dir) => {
    const f = dir === 1 ? 1 + SCALE_STEP : 1 - SCALE_STEP;
    const next = clone(manual);
    for (const s of STATS) {
      const k = s.k;
      if (locks[k]) continue;
      const v = grid[k]?.[r];
      if (v == null) continue;
      next[k] ||= {};
      const hi = r === 0 ? s.lv1Limit : s.limit;
      next[k][r] = String(clamp(scaleVal(v, f), s.lowest, hi));
    }
    setManualSafe(next);
  };

  const scaleCol = (k, dir) => {
    if (locks[k]) return;
    const f = dir === 1 ? 1 + SCALE_STEP : 1 - SCALE_STEP;
    const next = clone(manual);
    for (let r = 0; r < LEVELS; r++) {
      const v = grid[k]?.[r];
      if (v == null) continue;
      const meta = byKey[k];
      const hi = r === 0 ? meta.lv1Limit : meta.limit;
      next[k] ||= {};
      next[k][r] = String(clamp(scaleVal(v, f), meta.lowest, hi));
    }
    setManualSafe(next);
  };

  const toggleLock = (k) => {
    const next = { ...locks, [k]: !locks[k] };
    if (next[k]) {
      const m2 = clone(manual);
      m2[k] = { 0: "0" };
      setManualSafe(m2);
    }
    setLocksSafe(next);
  };

  const applyDefaultMults = (val) => {
    const next = emptyMults();
    for (const s of STATS) {
      if (["QUICK", "BBACK", "ENRGY", "REGEN"].includes(s.k)) continue;
      next[s.k] = Array.from({ length: STEPS }, () => String(val));
    }
    setMultSafe(next);
  };

  const resetAll = () => {
    setErr(null);
    setManual({});
    setMults(emptyMults());
    setSelectedTags([]);
    setIgnoredTags([]);
    setLocks({});
  };

  const exportPayload = () => {
    const payload = {
      version: 2,
      cap: CAP,
      stats: Object.fromEntries(STATS.map((s) => [s.k, (grid[s.k] ?? Array(LEVELS).fill(0)).map((v) => int(v ?? 0))])),
      multipliers: mults,
      tracked: {
        firstNonZero: tracked.firstNonZero,
        manualJumps: tracked.jumps,
        timeline: tracked.timelineLines,
      },
      tags: { selected: selectedTags, ignored: ignoredTags, active: activeTags },
    };
    return payload;
  };

  const copyJSON = async () => {
    const payload = exportPayload();
    try {
      await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1200);
    } catch {
      fail("Clipboard blocked.");
    }
  };

  const downloadJSON = () => {
    const payload = exportPayload();
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "stat-sheet.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const onImportFile = async (file) => {
    const txt = await file.text();
    const data = JSON.parse(txt);
    if (data?.version === 2 && data?.stats) {
      const m = {};
      for (const s of STATS) {
        const arr = data.stats[s.k] || [];
        const col = {};
        for (let r = 0; r < LEVELS; r++) col[r] = String(arr[r] ?? 0);
        m[s.k] = col;
      }
      setMultSafe(data.multipliers ?? emptyMults());
      setSelectedTags(data.tags?.selected ?? []);
      setIgnoredTags(data.tags?.ignored ?? []);
      setLocks(data.locks ?? {});
      setManualSafe(m);
      return;
    }
    const converted = convertOldPayload(data);
    setMultSafe(converted.mults);
    setManualSafe(converted.manual);
  };

  const loadPreset = async (name) => {
    const res = await fetch(`/${name}.json`);
    const data = await res.json();
    const converted = convertOldPayload(data);
    setMultSafe(converted.mults);
    setManualSafe(converted.manual);
  };

  const reorder = (idx, dir) => {
    const next = [...selectedTags];
    const j = idx + dir;
    if (j < 0 || j >= next.length) return;
    [next[idx], next[j]] = [next[j], next[idx]];
    setSelectedTags(next);
  };

  const addTag = (id) => {
    if (selectedTags.includes(id)) return;
    setSelectedTags([...selectedTags, id]);
  };

  const removeTag = (id) => setSelectedTags(selectedTags.filter((x) => x !== id));

  const generate = () => {
    const accepted = [];
    const ignored = [];
    for (const id of selectedTags) {
      const conflicts = tagConflicts[id] || [];
      const bad = accepted.some((a) => conflicts.includes(a) || (tagConflicts[a] || []).includes(id));
      if (bad) ignored.push(id);
      else accepted.push(id);
    }
    let state = { manual: {}, mults: emptyMults(), locks: clone(locks) };
    state.mults = clone(mults);
    const plan = mkPlanner({ manual: state.manual, mults: state.mults, locks: state.locks });
    for (const s of STATS) {
      if (plan.locks[s.k]) plan.zero(s.k);
    }
    plan.ensureL1("HPMAX", byKey.HPMAX.lv1Exp);
    plan.ensureL1("QUICK", byKey.QUICK.lv1Exp);
    plan.ensureL1("BBACK", byKey.BBACK.lv1Exp);

    const tagById = Object.fromEntries(TAGS.map((t) => [t.id, t]));
    const runTag = (id) => {
      const t = tagById[id];
      if (!t) return;
      try { t.apply(plan); } catch {  }
    };

    for (let i = 0; i < accepted.length; i++) {
      runTag(accepted[i]);
      for (let j = i - 1; j >= 0; j--) runTag(accepted[j]);
    }

    for (let it = 0; it < 16; it++) {
      const g = computeGrid(plan.manual, plan.mults);
      const d = derived(g);
      if (d.TOTAL >= CAP - 40) break;
      const primary = plan.topAttack() || "ATMEL";
      const bump = (k) => {
        if (plan.locks[k]) return;
        const meta = byKey[k];
        const cur = g[k]?.[0] ?? 0;
        const hi = meta.lv1Limit;
        if (cur >= hi) return;
        plan.setL1(k, cur + 1);
      };
      if (!accepted.includes("LOW_HEALTH")) bump("HPMAX");
      if (!accepted.includes("WEAK_ATTACK") && !accepted.includes("PACIFIST") && !accepted.includes("PURE_SUPPORT")) bump(primary);
      if (accepted.includes("DEFENDER") || accepted.includes("TANK")) bump("SHILD");
    }

    const v = validatePlan(plan.manual, plan.mults);
    if (!v.ok) return fail(v.reason);
    setIgnoredTags(ignored);
    setManual(plan.manual);
    setMults(plan.mults);
  };

  const groups = [
    { label: "CORE", span: 3 },
    { label: "ATTACK", span: 6 },
    { label: "UTIL", span: 5 },
    { label: "DEFENCE", span: 6 },
    { label: "TRAITS", span: 7 },
    { label: "LEVEL", span: 1 },
  ];

  const visibleCols = (() => {
    const out = [];
    for (const s of STATS) {
      out.push({ kind: "base", k: s.k, l: s.l });
      if (s.k === "ATSPX") {
        out.push({ kind: "derived", k: "ATK_SUM", l: "SUM", t: "number" });
        out.push({ kind: "derived", k: "ATK_TOP", l: "TOP", t: "text" });
      }
      if (s.k === "DDSPX") {
        out.push({ kind: "derived", k: "DEF_SUM", l: "SUM", t: "number" });
        out.push({ kind: "derived", k: "DEF_TOP", l: "TOP", t: "text" });
      }
    }
    out.push({ kind: "derived", k: "LV_TOTAL", l: "TOTAL", t: "number" });
    return out;
  })();

  const cellTone = (k, v) => {
    if (v == null) return "";
    const vi = int(v);
    if (vi === 0) return "zero-cell";
    if (vi < 0) return "neg-cell";
    return "";
  };

  const boundary = (k) => {
    if (k === "HPMAX") return "";
    if (k === "QUICK") return "border-l-2 border-l-black/10";
    if (k === "ATMEL") return "border-l-2 border-l-black/10";
    if (k === "ATK_TOP") return "border-r-2 border-r-black/10";
    if (k === "HEALR") return "border-l-2 border-l-black/10";
    if (k === "DDMEL") return "border-l-2 border-l-black/10";
    if (k === "DEF_TOP") return "border-r-2 border-r-black/10";
    if (k === "EVADE") return "border-l-2 border-l-black/10";
    if (k === "LV_TOTAL") return "border-l-2 border-l-black/10";
    return "";
  };

  const tagChip = (id, active) => (
    <span
      key={id}
      className={
        "inline-flex items-center gap-1 rounded-full border px-2 py-1 text-xs " +
        (active ? "bg-emerald-50 border-emerald-200 text-emerald-700" : "bg-white border-black/10 text-black/70")
      }
      title={id}
    >
      {id}
    </span>
  );

  return (
    <div className="p-4 md:p-6 max-w-[1800px] mx-auto">
      <div className="rounded-2xl border shadow-sm bg-white">
        <div ref={topBarRef} className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b">
          <div className="p-4 md:p-5">
            <div className="flex flex-col gap-3">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-3">
                <div>
                  <div className="text-xl font-semibold">Stat Sheet Generator</div>
                  <div className="text-sm text-black/60 mt-1">
                    Integer-only. Per-stat multipliers (3dp) populate downward. Total cap {CAP}.
                  </div>
                  {err && (
                    <div className="mt-2 inline-flex items-center gap-2 text-sm text-rose-600">
                      <AlertTriangle className="h-4 w-4" />
                      <span>{err}</span>
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <div className={"flex items-center gap-2 rounded-xl border px-3 py-2 " + (der.TOTAL >= CAP ? "border-rose-300" : "border-black/10")}>
                    <span className="text-sm text-black/60">Total</span>
                    <span className="font-semibold tabular-nums">{int(der.TOTAL)} / {CAP}</span>
                  </div>

                  <button className="btn" onClick={copyJSON}>
                    {copied ? <ClipboardCheck className="h-4 w-4" /> : <Clipboard className="h-4 w-4" />}
                    <span>Copy JSON</span>
                  </button>

                  <button className="btn" onClick={downloadJSON}>
                    <Download className="h-4 w-4" />
                    <span>Export JSON</span>
                  </button>

                  <button className="btn" onClick={() => fileRef.current?.click()}>
                    <Upload className="h-4 w-4" />
                    <span>Import</span>
                  </button>
                  <input
                    ref={fileRef}
                    type="file"
                    accept="application/json"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (!f) return;
                      onImportFile(f).catch(() => fail("Import failed."));
                      e.target.value = "";
                    }}
                  />

                  <button className="btn" onClick={() => loadPreset("baseline").catch(() => fail("Couldn’t load baseline."))}>
                    <span>Load baseline</span>
                  </button>

                  <button className="btn" onClick={() => loadPreset("char1").catch(() => fail("Couldn’t load char1."))}>
                    <span>Load char1</span>
                  </button>

                  <button className="btn" onClick={resetAll}>
                    <RotateCcw className="h-4 w-4" />
                    <span>Reset</span>
                  </button>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="text-xs font-semibold text-black/50">Selected tags</div>
                  <div className="flex flex-wrap gap-1 max-h-16 overflow-auto">
                    {selectedTags.length ? selectedTags.map((id, i) => (
                      <span key={id} className="inline-flex items-center gap-1 rounded-full border px-2 py-1 text-xs bg-black/[0.03] border-black/10">
                        <span className="text-black/40">{i + 1}.</span>
                        <span className="font-mono">{id}</span>
                      </span>
                    )) : <span className="text-sm text-black/40">None.</span>}
                  </div>
                  <div className="ml-auto">
                    <button className="btn btn-primary" onClick={generate}>
                      <Play className="h-4 w-4" />
                      <span>Generate</span>
                    </button>
                  </div>
                </div>

                {ignoredTags.length > 0 && (
                  <div className="text-xs text-amber-700">
                    Ignored (conflicts with higher priority): <span className="font-mono">{ignoredTags.join(", ")}</span>
                  </div>
                )}

                <div className="flex flex-wrap items-center gap-2">
                  <div className="text-xs font-semibold text-black/50">Auto tags met</div>
                  <div className="flex flex-wrap gap-1 max-h-16 overflow-auto">
                    {activeTags.length ? activeTags.map((id) => tagChip(id, true)) : <span className="text-sm text-black/40">None.</span>}
                  </div>
                </div>

                <Collapsible title="Learn / boost timeline" defaultOpen={true}>
                  <div className="max-h-28 overflow-auto space-y-1">
                    {tracked.timelineLines.length ? tracked.timelineLines.map((ln, i) => (
                      <div key={i} className="text-xs font-mono text-black/70">{ln}</div>
                    )) : <div className="text-sm text-black/40">None.</div>}
                  </div>
                </Collapsible>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 md:p-5 border-b">
          <div className="grid lg:grid-cols-2 gap-2">
            <Collapsible title="Tag picker (order matters)" defaultOpen={true}>
              <div className="mt-1 flex flex-wrap gap-2">
                {selectedTags.length ? selectedTags.map((id, idx) => (
                  <span key={id} className="inline-flex items-center gap-1 rounded-full border px-2 py-1 text-xs bg-black/[0.03] border-black/10">
                    <span className="font-mono">{id}</span>
                    <button className="iconbtn" title="Move up" onClick={() => reorder(idx, -1)}><ArrowUp className="h-3 w-3" /></button>
                    <button className="iconbtn" title="Move down" onClick={() => reorder(idx, 1)}><ArrowDown className="h-3 w-3" /></button>
                    <button className="iconbtn" title="Remove" onClick={() => removeTag(id)}><X className="h-3 w-3" /></button>
                  </span>
                )) : <div className="text-sm text-black/40">No selected tags.</div>}
              </div>

              <div className="mt-3 grid grid-cols-2 md:grid-cols-3 gap-2 max-h-56 overflow-auto">
                {TAGS.filter((t) => t.selectable).map((t) => (
                  <button
                    key={t.id}
                    className={"tagbtn " + (selectedTags.includes(t.id) ? "tagbtn-on" : "")}
                    onClick={() => addTag(t.id)}
                    title={t.name}
                  >
                    <span className="font-mono">{t.id}</span>
                    <span className="truncate">{t.name.replace(/^\d+\s*/, "")}</span>
                  </button>
                ))}
              </div>
            </Collapsible>

            <Collapsible
              title="Locks (force zero all levels)"
              defaultOpen={false}
              right={
                <div className="flex items-center gap-2">
                  <Wand2 className="h-4 w-4 text-black/40" />
                  <button className="btn" onClick={() => applyDefaultMults(1.25)}>Apply 1.25 mults</button>
                  <button className="btn" onClick={() => applyDefaultMults(1)}>All mults = 1</button>
                </div>
              }
            >
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {STATS.map((s) => (
                  <button
                    key={s.k}
                    className={"lockbtn " + (locks[s.k] ? "lockbtn-on" : "")}
                    onClick={() => toggleLock(s.k)}
                    style={{ borderColor: `hsla(${statHue(s.k)},70%,40%,0.25)` }}
                    title="Lock stat to zero"
                  >
                    <span className="inline-block h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: `hsl(${statHue(s.k)},70%,55%)` }} />
                    <span className="font-mono">{s.k}</span>
                  </button>
                ))}
              </div>
            </Collapsible>
          </div>

          <div className="mt-2 grid lg:grid-cols-2 gap-2">
            <Collapsible title="Stat bounds" defaultOpen={false}>
              <StatBoundsTable />
            </Collapsible>
            <Collapsible title="Rules" defaultOpen={false}>
              <div className="text-xs text-black/60 leading-relaxed">
                <ul className="list-disc pl-5 space-y-1">
                  <li>Entering a value sets an override only for that cell. Cells below auto-fill using that column’s multipliers.</li>
                  <li>Multipliers are editable per column per step and apply to all steps below by default.</li>
                  <li>No stat can decrease down a column. Total (absolute) across all base cells must stay ≤ {CAP}.</li>
                  <li>Row/column ± scales by 10% and never scales a 0 into a 1.</li>
                </ul>
              </div>
            </Collapsible>
          </div>
        </div>

        <div className="p-4">
          <div className="overflow-auto rounded-2xl border">
            <table className="min-w-max w-full text-xs">
              <thead className="sticky z-10 bg-white" style={{ top: "var(--topbar-h, 0px)" }}>
                <tr>
                  <th rowSpan={2} className="sticky left-0 z-20 bg-white text-left px-2 py-2 border-b min-w-[110px]">
                    Level
                  </th>
                  {groups.map((g) => (
                    <th key={g.label} colSpan={g.span} className="px-1 py-2 border-b text-center text-[11px] font-semibold tracking-wide text-black/50">
                      {g.label}
                    </th>
                  ))}
                </tr>
                <tr>
                  {visibleCols.map((c) => {
                    if (c.kind === "derived") {
                      return (
                        <th key={c.k} className={`px-1 py-2 border-b text-right min-w-[54px] ${boundary(c.k)} text-black/40`}>
                          {c.l}
                        </th>
                      );
                    }
                    const locked = !!locks[c.k];
                    return (
                      <th key={c.k} className={`px-1 py-2 border-b text-right min-w-[54px] ${boundary(c.k)}`}>
                        <div className="flex items-center justify-end gap-1">
                          <span className={"font-mono " + (locked ? "text-black/30 line-through" : "")}>{c.l}</span>
                          <div className="flex flex-col gap-0.5">
                            <button type="button" className="mini" title="Scale column +10%" onClick={() => scaleCol(c.k, 1)} disabled={locked}>+</button>
                            <button type="button" className="mini" title="Scale column −10%" onClick={() => scaleCol(c.k, -1)} disabled={locked}>−</button>
                          </div>
                        </div>
                      </th>
                    );
                  })}
                </tr>
              </thead>

              <tbody>
                {Array.from({ length: LEVELS }, (_, r) => {
                  const last = r === LEVELS - 1;
                  return (
                    <React.Fragment key={`r-${r}`}>
                      <tr className="hover:bg-black/[0.02]">
                        <td className="sticky left-0 z-10 bg-white px-2 py-2 border-b font-medium">
                          <div className="flex items-center justify-between gap-2">
                            <span>Lv{r + 1}</span>
                            <div className="flex items-center gap-1">
                              <button type="button" className="rowbtn" title="Scale row +10%" onClick={() => scaleRow(r, 1)}>+</button>
                              <button type="button" className="rowbtn" title="Scale row −10%" onClick={() => scaleRow(r, -1)}>−</button>
                            </div>
                          </div>
                        </td>

                        {visibleCols.map((c) => {
                          const cls = `px-1 py-1 border-b ${boundary(c.k)}`;
                          if (c.kind === "derived") {
                            if (c.t === "text") {
                              const v = der[c.k]?.[r] ?? "";
                              return (
                                <td key={`${c.k}-${r}`} className={cls}>
                                  <div className="h-8 px-2 flex items-center justify-end rounded-lg border bg-black/[0.03] text-black/50 font-mono">
                                    {v}
                                  </div>
                                </td>
                              );
                            }
                            const v = der[c.k]?.[r] ?? 0;
                            return (
                              <td key={`${c.k}-${r}`} className={cls}>
                                <div className="h-8 px-2 flex items-center justify-end rounded-lg border bg-black/[0.03] text-black/60 tabular-nums">
                                  {int(v)}
                                </div>
                              </td>
                            );
                          }

                          const ms = manual[c.k]?.[r];
                          const isMan = ms !== undefined;
                          const v = grid[c.k]?.[r];
                          const show = isMan ? ms : (v == null ? "" : String(int(v)));
                          const auto = !isMan && r > 0 && v != null;
                          const locked = !!locks[c.k];
                          const tone = cellTone(c.k, v);
                          const meta = byKey[c.k];

                          return (
                            <td key={`${c.k}-${r}`} className={cls}>
                              <div className="relative">
                                <input
                                  className={
                                    "h-8 w-[54px] rounded-lg border px-1 text-right tabular-nums outline-none focus:ring-2 focus:ring-black/10 " +
                                    (auto ? "bg-black/[0.02]" : "bg-white") +
                                    " " + tone
                                  }
                                  style={{ ...colStyle(c.k, 0.08), ...borderStyle(c.k, 0.35), ...(locked ? { opacity: 0.45 } : {}) }}
                                  type="number"
                                  step={1}
                                  inputMode="numeric"
                                  value={show}
                                  disabled={locked}
                                  onChange={(e) => setCell(c.k, r, e.target.value)}
                                  onBlur={(e) => {
                                    const nv = num(e.target.value);
                                    if (nv == null) return;
                                    const hi = r === 0 ? meta.lv1Limit : meta.limit;
                                    e.target.value = String(clamp(int(nv), meta.lowest, hi));
                                  }}
                                />
                                {isMan && !locked && (
                                  <button type="button" className="clearbtn" title="Clear override" onClick={() => clearCell(c.k, r)}>×</button>
                                )}
                              </div>
                            </td>
                          );
                        })}
                      </tr>

                      {!last && (
                        <tr className="bg-black/[0.02]">
                          <td className="sticky left-0 z-10 bg-black/[0.02] px-2 py-2 border-b text-[11px] text-black/50">
                            Mult → Lv{r + 2}
                          </td>

                          {visibleCols.map((c) => {
                            if (c.kind === "derived") {
                              return <td key={`m-${c.k}-${r}`} className={`px-1 py-1 border-b ${boundary(c.k)}`} />;
                            }
                            const locked = !!locks[c.k];
                            const v = mults[c.k]?.[r] ?? "1";
                            return (
                              <td key={`m-${c.k}-${r}`} className={`px-1 py-1 border-b ${boundary(c.k)}`}>
                                <input
                                  className="h-7 w-[54px] rounded-lg border px-1 text-right tabular-nums outline-none focus:ring-2 focus:ring-black/10"
                                  style={{ ...colStyle(c.k, 0.06), ...borderStyle(c.k, 0.25), ...(locked ? { opacity: 0.4 } : {}) }}
                                  type="number"
                                  step={0.001}
                                  value={v}
                                  disabled={locked}
                                  onChange={(e) => setMultCell(c.k, r, e.target.value)}
                                  onBlur={(e) => setMultCell(c.k, r, norm3(e.target.value))}
                                  title="Edits this step AND all below for this column"
                                />
                              </td>
                            );
                          })}
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex flex-wrap gap-2 text-xs text-black/60">
            <span className="inline-flex items-center gap-1 rounded-full border px-2 py-1 bg-white border-black/10">
              <span className="h-2.5 w-2.5 rounded-sm zero-swatch" />
              0 values
            </span>
            <span className="inline-flex items-center gap-1 rounded-full border px-2 py-1 bg-white border-black/10">
              <span className="h-2.5 w-2.5 rounded-sm neg-swatch" />
              negative values
            </span>
            <span className="inline-flex items-center gap-1 rounded-full border px-2 py-1 bg-white border-black/10">
              Multipliers default to 1. Editing a multiplier copies it downward in that column.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
